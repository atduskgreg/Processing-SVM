/**
 * P-SVM
 * A machine learning library based on the LibSVM Support Vector Machines Library.
 * http://makematics.com/code/psvm
 *
 * Copyright (C) 2012 Greg Borenstein http://makematics.com
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author      Greg Borenstein http://makematics.com
 * @modified    09/12/2012
 * @version     0.1.1 (1)
 */

package psvm;

import java.io.IOException;

import processing.core.*;

import libsvm.*;


/**
 * This is a template class and can be used to start a new processing library or tool.
 * Make sure you rename this class as well as the name of the example package 'template' 
 * to your own library or tool naming convention.
 * 
 * @example Hello 
 * 
 * (the tag @example followed by the name of an example included in folder 'examples' will
 * automatically include the example in the javadoc.)
 *
 */

//	public final static String VERSION = "0.1.1";


public class SVM {
	  public svm_parameter params;
	  public svm_model model;
	  public SVMProblem svmProblem;
	  PApplet parent;

	  SVM(PApplet parent) {
		this.parent = parent;
	    
		params = new svm_parameter();
	    params.svm_type = svm_parameter.C_SVC;//NU_SVC;
	    params.kernel_type = svm_parameter.LINEAR;//RBF;
	    params.degree = 3;

	    params.gamma = 0;
	    params.C = 100;
	    params.coef0 = 0;
	    params.nu = 0.5;
	    params.cache_size = 100;
	    params.eps = 1e-3;
	    params.p = 0.1;
	    params.shrinking = 1;
	    params.probability = 0;
	    params.nr_weight = 0;
	    params.weight_label = new int[0];
	    params.weight = new double[0];
	  }

	  // NOTE: The model file 
	  void loadModel(String filename) {
	    try {
	      model = svm.svm_load_model(parent.dataPath(filename));
	      svmProblem = new SVMProblem();
	      svmProblem.setNumFeatures(model.nr_class);
	    } 
	    catch(IOException e) {
	      parent.println("[P-SVM] ERROR loading model. Is the model file in the data folder? " + e);
	    }
	  }

	  // Note: the sketch has to have a data folder
	  //       for this to work.
	  void saveModel(String filename) {
	    try {
	      svm.svm_save_model(parent.dataPath(filename), model);
	    } 
	    catch(IOException e) {
	      parent.println("[P-SVM] ERROR saving model. Does your sketch have a data folder? " + e);
	    }
	  }

	  void train(SVMProblem problem) {
	    params.gamma = (float)1/problem.problem.l;
	   // parent.println("gamma: " + params.gamma);
	    model = svm.svm_train(problem.problem, params);   
	    svmProblem = problem;
	  }

	  double test(int[] testVector) {
	    svm_node[] result = new svm_node[svmProblem.getNumFeatures()];
	    for (int f = 0; f < svmProblem.getNumFeatures(); f++) {
	      result[f] = new svm_node();
	      result[f].index = f+1; 
	      result[f].value = testVector[f];
	    }
	    return svm.svm_predict(model, result);
	  }
	}
